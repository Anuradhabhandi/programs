class Sum1 
{
	public static void main(String[] args) 
	{
		int n=256,rem;
		while(n>0)
		{
			rem=n%10;
			System.out.println(rem);
			n=n/10;
			
		}
		
	}
}
