class Digit2 
{
	public static void main(String[] args) 
	{
		int num=256,rem,sum=0;
		while(num>0)
		{
			rem=num%10;
			if(num%2==1)
		System.out.println(rem);
			num=num/10;
		}
	}
}
