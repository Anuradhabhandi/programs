class Program21 
{
	public static void main(String[] args) 
	{
		int n=28,f=1,sum=0;
		while(f<n)
		{
			if(n%f==0)
			{
				sum=sum+f;
			}
			f++;
		}
		if(sum==n)
		{
			System.out.println(n+"is a perfect number");
		}
		else
		{
			System.out.println(n+"is not a perfect number");
		}
	}
}
