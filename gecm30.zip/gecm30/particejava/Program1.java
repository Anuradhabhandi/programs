class Program1 
{
	public static void main(String[] args) 
	{
		char ch='a';
		if((ch>='0' && ch<='9'))
		{

		System.out.println(ch + "is conatin a cahracter");
		}
		else
		{
		 System.out.println(ch+"is not conatin a cahracter");
		}

	}
}
