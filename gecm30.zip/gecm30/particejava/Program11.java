class Program11 
{
	public static void main(String[] args) 
	{
		int n=1;
		char ch='A';
		char ch1='a';
		while(ch<='Z')
		{
			System.out.println(ch+" "+n+ch1);
			ch++;
			ch1++;
			n++;
		}
	}
}
