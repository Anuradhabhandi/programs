class Pattern26 
{
	public static void main(String[] args) 
	{
		
	}
}
