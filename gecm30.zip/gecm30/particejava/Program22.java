class Program22 
{
	public static void main(String[] args) 
	{
		int num=121,rev=0,rem,n=num;
		while(num>0)
		{
			rem=num%10;
			rev=(rev*10)+rem;
			num=num/10;
		}
		if(n==rev)
		{
			System.out.println("given number is palindrome");
		}
		else
		{
			System.out.println("given number is not palindrome");
		}
	}
}
