class ArmStrong
{
	public static void main(String[] args) 
	{
		int num=10,sum=0,rem,count=0,n=num;
		while(num>0)
		{
			count++;
			num=num/10;
		}
		num=n;
		while(n>0)
		{
			rem=n%10;
			sum=sum+rem;
			n=n/10;
		}
		if(num==sum)
		{
			System.out.println("given no is armstrong");
		}
		else
		{
			System.out.println("given no is armstrong");
		}
	}
		public static int count(int rem,int count)
		{
			int pro=1;
			for(int i=1;i<=count;i++)
			{
				pro=pro*rem;
			}
			return pro;
		


	}
}
