class Program17 
{
	public static void main(String[] args) 
	{
		int a=0,b=1,c=0;
		System.out.println(a);
		System.out.println(b);
		while((a+b)<=100)
		{
			c=a+b;
			System.out.println(c);
			a=b;
			b=c;
		}
	}
}
