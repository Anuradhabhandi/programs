class Pattern36
{
	public static void main(String[] args)
	{
	int space=3,star=0;
	for(int i=1;i<=5;i++)
	{
	if(i<=3)
	{
	star++;
	space--;
	}
	else
	{
	star--;
	space++;
	}
	for(int j=1;j<=star;j++)
	{
	System.out.print("*");
	}
	for(int j=1;j<=space;j++)
	{
	System.out.print(" ");
	}
	for(int j=1;j<=1;j++)
	{
	System.out.print("*");
	}
	for(int j=1;j<=space;j++)
	{
	System.out.print(" ");
	}
	for(int j=1;j<=star;j++)
	{
	System.out.print("*");
	}
	System.out.println();
	}
	}
}