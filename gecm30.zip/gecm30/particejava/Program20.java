class Program20 
{
	public static void main(String[] args) 
	{
	   int num=1124,sum=0,rem,product=1;
	   while(num>0)
		{
		   rem=num%10;
		   sum=sum+rem;
		   product=product*rem;
		   num=num/10;
		}
		if(sum==product)
		{
			System.out.println("given number is spy");
		}
		else
		{
			System.out.println("given number is not a spy");
		}

	}
}
