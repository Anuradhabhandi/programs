class Program15 
{
	public static void main(String[] args) 
	{
		int a=10,b=20;
		System.out.println("before swapping");
		System.out.println(a);
		System.out.println(b);
		int c=a+b;
		a=b;
		b=c;
		System.out.println("after swapping");
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
}
