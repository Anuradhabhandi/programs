class Program4 
{
	public static void main(String[] args) 
	{
		char ch='7';
		if((ch>='a' && ch<='z')||(ch>='A' && ch<='Z'))
		{
			System.out.println(ch+" is conatin a alpahbet");
		}
		else if(ch>='0' && ch<='9')
		{
			System.out.println(ch+"is contain a digit");
		}
		else
		{
			System.out.println(ch+"is conatin a special characetr");
		}
	}
}
