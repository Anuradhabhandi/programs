class  Pattern34
{
	public static void main(String[] args) 
	{
		int star=0,space=4,star1=0,space1=5;
		for(int i=1;i<=7;i++)
		{
			if(i<=4)
			{
				star++;
				space--;
				star1++;
				
				
			}
			else
			{
				star--;
				space++;
				star1--;
				
			}
			
			
            
			for(int j=1;j<=space;j++)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=star;j++)
			{
				System.out.print("*");
			}
			for(int i1=1;i1<=4;i1++)
			{
				if(i==3||(i==4||i==5))
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}

			
			for(int j=1;j<=star1;j++)
			{
				System.out.print("*");
			}
			
			

           System.out.println();
		}
	}
}
