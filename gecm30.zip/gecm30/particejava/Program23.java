class Program23 
{
	public static void main(String[] args) 
	{
		int num=145,sum=0,rem,n=num;
		while(num>0)
		{
			rem=num%10;
			num=num/10;
			sum=sum+fact(rem);
		}
		if(sum==n)
		{
			System.out.println("given number is strong");
		}
		else
		{
			System.out.println("given number is not a strong");
		}
	}
		public static int fact(int num)
		{
			int fact=1;
			for(int i=1;i<=num;i++)
			{
				fact=fact*i;
			}
			return fact;
		
	}
}
