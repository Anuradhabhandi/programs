class Program16 
{
	public static void main(String[] args) 
	{
		int m=10,n=2,res=1;
		for(int i=1;i<=n;i++)
		{
			res=res*m;
			
		}
		System.out.println(res);
	}
}
