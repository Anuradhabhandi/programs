class Program8 
{
	public static void main(String[] args) 
	{
		char ch='z';
		while(ch<='a')
		{
			System.out.println(ch);
		ch--;
		}
	}
}
