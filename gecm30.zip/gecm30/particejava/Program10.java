class Program10 
{
	public static void main(String[] args) 
	{
		//char ch='a',ch1='A';
		//while(ch<='z')
		//{
		//	System.out.println(ch+" "+ch1);
		//ch++;
		//ch1++;
		//}

		char ch='A';
		while(ch<='Z')
		{
			System.out.println(ch+" "+(char)(ch+32));
				ch++;
		}
	}
}
