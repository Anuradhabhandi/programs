class Program19 
{
	public static void main(String[] args) 
	{
		int n=10,sum=0,rem;
		int num=n*n;
		while (num>0)
		{
			rem=num%10;
			sum=sum+rem;
			num=num/10;
		}
		if(sum==n)
		{
			System.out.println("given number is neon");
		}
		else
		{
			System.out.println("given number is not a neon number");
		}
	}
}
