class Program13 
{
	public static void main(String[] args) 
	{
		double fact=1;
		for(int i=2;i<=200;i++)
		{
			fact=fact*i;
			System.out.println(fact);
		}
	}
}
