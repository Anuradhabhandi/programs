class Program3 
{
	public static void main(String[] args) 
	{
		char ch='4';
		if((ch>='a' && ch<='z')||(ch>='A' && ch<='Z'))
		{
			System.out.println(ch+"is conatin a alpahbet");
		}
		else
		{
		System.out.println(ch+"is not conatin a alphabet");
		}
	}
}
