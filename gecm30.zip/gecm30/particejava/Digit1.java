class Digit1 
{
	public static void main(String[] args) 
	{
		int num=256,rem,sum=0;
		while(num>0)
		{
			rem=num%10;
			sum=sum+(rem*rem);
		System.out.println(sum);
		
		}
	
	    num=num/10;
	}
}
