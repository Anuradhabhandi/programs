class Pattern35
{
	public static void main(String[] args)
	{
	int space=4,star=0;
	for(int i=1;i<=10;i++)
	{
	if(i<=4)
	{
	space--;
	star++;
	}
	else
	{
	space=4;
	star=2;
	}
	for(int j=1;j<=space;j++)
	{
	System.out.print(" ");
	}
	for(int j=1;j<=star;j++)
	{
	System.out.print("*");
	}
	if(i<=4)
	{
	for(int j=1;j<=2;j++)
	{
	System.out.print(" ");
	}
	for(int j=1;j<=star;j++)
	{
	System.out.print("*");
	}
	}
	System.out.println();
	}
	}
	
}
	