class Program2 
{
	public static void main(String[] args) 
	{
		char ch='4';
		if((ch>='a' && ch<='z'))
		{
			System.out.println(ch+" is contain a lowercasse ");
		}
		else
		{

		System.out.println(ch+"is not contain a lowercase");
		}
	}
}
