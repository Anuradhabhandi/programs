class Program11 
{
	public static void main(String[] args) 
	{
		int n=1;
		char ch='a';
		char ch1='A';
		while(ch<='Z')
		{
			System.out.println(ch);
			ch++;
			ch1++;
			n++;
		}
	}
}
