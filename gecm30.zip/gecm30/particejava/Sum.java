class Sum 
{
	public static void main(String[] args) 
	{
		int res=1,num=5;
		for(int i=1;i<=num;i++)
		{
			 res=res*i;
		
		}
		System.out.println(res);
	}
}
