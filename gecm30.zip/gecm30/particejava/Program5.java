class Program5
{
	public static void main(String[] args) 
	{
	  int i=8;
	  if((i%3==0)&&(i%4!=0))
		{
		  System.out.println("good morning");
		}
		else if((i%4==0)&&(i%3!=0))
		{
			System.out.println("good afternoon");
		}
		else if((i%4==0)&&(i%3==0))
		{
			System.out.println("good evening");
		}
		else
		{
			System.out.println("good night");
		}
	}
}
