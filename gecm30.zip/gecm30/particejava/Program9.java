class Program9 
{
	public static void main(String[] args) 
	{
		char ch='a';
		while(ch<='z')
		{
			if(ch%2==0)
			{
			System.out.println(ch);
				
			}
			ch++;
		}
	}
}
