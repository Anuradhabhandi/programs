class Number5
{
	public static void main(String[] args)
	{
	int star=0,space=4,n=1;
	for(int i=1;i<=4;i++)
	{
	star+=2;
	space--;
	if(i==2)
	{
	n=1;
	}
	for(int j=1;j<=space;j++)
	{
	System.out.print(" ");
	}
	for(int j=1;j<=star;j++)
	{
	System.out.print(n++);
	}
	System.out.println();
	}
	}
}
	