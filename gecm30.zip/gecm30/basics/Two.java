class Two
{
	public static void main(String[] args)
	{
	int a=40;
	int b=20;
	String c=((a>b)?"a is largest":"b is largest");
	System.out.println(c);
	}
}