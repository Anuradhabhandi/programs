class Odd{
	public static void main(String[] args)
	{
	int num=256,rem;
	while(num>0)
	{
	rem=num%10;
	if(num%2==1)
	System.out.println(rem);
	num=num/10;
	}
	}
}