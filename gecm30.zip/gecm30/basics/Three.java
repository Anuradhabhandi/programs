class Three
{
	public static void main(String[] args)
	{
	int a=70;
	int b=20;
	int c=50;
	String d=((a>b)||(a>c)&&(b>c)?"largest":"not largest");
	System.out.println(d);
	}
}
 