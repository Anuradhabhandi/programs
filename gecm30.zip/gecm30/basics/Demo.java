class Demo{
	public static void main(String[] args){	
	char ch='a';
	System.out.println("ch");
	System.out.println(ch);
	System.out.println(ch);
	ch=' ';
	System.out.println(ch);
	System.out.println("good byee");
}
}
	