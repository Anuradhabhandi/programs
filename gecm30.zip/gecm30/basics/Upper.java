class Upper
{
	public static void main(String args[])
	{
	char ch='A';
	if((ch>='A')&&(ch<='Z'))
	{
	System.out.println(ch+" is a contain uppercase letter");
	}
	else
	{
	System.out.println(ch+" is not contain uppercase letter");
	}
	}
}
	