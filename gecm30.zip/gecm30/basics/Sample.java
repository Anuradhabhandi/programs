class Sample
{
	public static void main(String[] args)
	{
	double d=35.56f;
	System.out.println(d);

	double d1='0';
	System.out.println(d1);

	int a='a';
	System.out.println(a);

	int a1=(int)98.98;
	System.out.println(a1);

	//long l1=809388456789244;
	//System.out.println(l1);

	float f2=89054678999999923445.0899f;
	System.out.println(f2);

	float f3=507831;
	System.out.println(f3);

	long l3=(long)34.5f;
	System.out.println(l3);
      }
}