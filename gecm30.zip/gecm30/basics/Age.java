class Age
{
	public static void main(String[] args)
	{
	int boyAge=5;
	int girlAge=21;
	String a=((boyAge>=21)&&(girlAge>=21)?"eligible":"not eligible");
	System.out.println(a);
	}
}