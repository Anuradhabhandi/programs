class Switch
{
	public static void main(String[] args)
	{
	char ch='z';
	if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z'))
	{
	switch(ch)
	{
        case 'a':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'e':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'i':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'o':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'u':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'A':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'E':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'I':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'O':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	case 'U':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	default:
	{
	System.out.println(ch + " is a consantant");
	break;
	}
	}
	}
	else
	{
	System.out.println(ch +" is not contain  a character");
	
	}
	
	}
}