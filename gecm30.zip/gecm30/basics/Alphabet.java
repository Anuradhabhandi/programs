class Alphabet
{
	public static void main(String[] args)
	{
	char ch='a';
	if(char>='a'&& char<='z')||(char>='A' && char<='Z')
	{
	System.out.println(ch+" is a contain alphabet letter");
	}
	else
	{
	System.out.println(ch+" is not contain alphabet letter");
	}
	}
}
	