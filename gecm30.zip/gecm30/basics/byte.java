class Byte
{
	public Static void main(String[] args)
	{

	Byte b=5;
	Byte c=10;
	Byte d=b+c;
	System.out.println(d);
	}
}