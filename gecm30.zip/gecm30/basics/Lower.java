class Lower
{
	public static void main(String args[])
	{
	char ch='A';
	if((ch>='a')&&(ch<='z'))
	{
	System.out.println(ch + " is a lowercase alphabet");
	}
	else
	{
	System.out.println(ch + " is not lowercase alphabet");
	}
	}
}
	