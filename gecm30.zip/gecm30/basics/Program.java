class Program
{
	public static void main(String[] args)
	{
	char ch='2';
	if((ch>='a' && ch<='z')||(ch>='A' && ch<='z'))
	{
	System.out.println(ch+"contains an alphabet");
	}
	else if((ch>='0' && ch<='9'))
	{
	System.out.println(ch+"contains a digit");
	}
	else
	{
	System.out.println(ch+"contain special character");
	}
	}
}