class Char
{
	public static void main(String args[])
	{
	char ch='5';
	if((ch>='0')&&(ch<='9'))
	{
	System.out.println(ch+"is a digit");
	}
	else
	{
	System.out.println(ch+"is not a digit");
	}
	}
}
	