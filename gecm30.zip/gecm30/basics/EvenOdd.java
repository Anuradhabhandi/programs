class EvenOdd
{
	public static void main(String[] args)
	{
	int a=24;
	String b=((a%2==0)?"given number is even":"given number is odd");
	System.out.println(b);
	}
}