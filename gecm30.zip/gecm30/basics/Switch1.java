class Switch1
{
	public static void main(String[] args)
	{
	char ch='A';
	if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z'))
	{
	switch(ch)
	{
        case 'a':
	case 'e':
	case 'i':
	case 'o':
	case 'u':
	case 'A':
	case 'E':
	case 'I':
	case 'O':
	case 'U':
	{
	System.out.println(ch+" is a vowel");
	break;
	}
	default:
	{
	System.out.println(ch + " is a consantant");
	break;
	}
	}
	}
	else
	{
	System.out.println(ch +" is not contain  a character");
	
	}
	
	}
}