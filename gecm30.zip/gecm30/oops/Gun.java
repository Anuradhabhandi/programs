class Gun 
{
	String color;
	int bullet;

	public void shoot(){
		System.out.println("Gun color is: "+this.color+" no. of bullet is: "+this.bullet);
	}
}
