class Rectangle
{
	double length;
	double breadth;
	
	public void areaOfRectangle(){
		System.out.println("Area of rec is: "+(this.length*this.breadth));
	}
	

}
