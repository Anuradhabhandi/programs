class AreaOfRectangle 
{
	public static void main(String[] args) 
	{
		Rectangle r1= new Rectangle();
		r1.length=4.5;
		r1.breadth=3.5;
		r1.areaOfRectangle();
		
		Rectangle r2= new Rectangle();
		r2.length=7.5;
		r2.breadth=4.5;
		r2.areaOfRectangle();
		
	}
}
