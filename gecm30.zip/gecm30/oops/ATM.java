class ATM 
{
	String branchName;
	int pin;
	long amount;

	public void deposit(){
		System.out.println(this.amount);
	}
    public void withDraw(){
		System.out.println(this.pin);
	}

}
