class Bank 
{
	public static void main(String[] args) 
	{
		ATM a1=new ATM();
		    a1.branchName="SIB";
	        a1.pin=342;
	        a1.amount=4000876;
			a1.deposit();
			a1.withDraw();
			
			ATM a2=new ATM();
		    a2.branchName="Bankofmah";
	        a2.pin=242;
	        a2.amount=5600876;
			a2.deposit();
			a2.withDraw();
			
			ATM a3=new ATM();
		    a3.branchName="HDFC";
	        a3.pin=142;
	        a3.amount=67500876;
			a3.deposit();
			a3.withDraw();
	}
}
