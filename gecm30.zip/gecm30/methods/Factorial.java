class Factorial 
{
	public static void main(String[] args) 
	{
		int num=5;
		int res=1;
		factorial(num,res);
		System.out.println("main ends...");
	}
	public static void factorial(int num1,int res1)
	{
		for(int i=1;i<=num1;i++)
		{
			res1=res1*i;
		}
		System.out.println(res1);
	}
}
