class Methods2
{
	public static void main(String[] args)
	{
	addition();
	System.out.println("main ends...");
	}
	public static void addition()
	{
	double d1=20.0;
	double d2=30.0;
	double c=d1+d2;
	System.out.println(c);
}	}