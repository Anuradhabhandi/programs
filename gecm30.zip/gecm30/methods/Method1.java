class Method1
{
	public static void main(String[] args)
	{
	logIn();
	System.out.println("main ends..");
	}
	public static void logIn()
	{
	String username="vanita";
	String password="@123vanu";
	System.out.println("username is succesful");
	}
}