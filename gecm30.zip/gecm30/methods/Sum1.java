class Sum1
{
	public static void main(String[] args) 
	{
		int sum=sum(1);
		System.out.println(sum);
	}
	public static int sum(int n)
	{
		if(n==10)
			return 10;
		else
			return n+sum(n+1);
	}
}

