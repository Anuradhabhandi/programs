class Method3
{
	public static void main(String[] args)
	{
	contact();
	System.out.println("main ends...");
	}
	public static void contact()
	{
	long std_code=0400l;
	long phone_no=9880020224l;
	System.out.println(std_code+"-"+phone_no);
	}
}