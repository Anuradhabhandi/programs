class Product
{
	public static void main(String[] args) 
	{
		int pro=pro(1);
		System.out.println(pro);
	}
	public static int pro(int n)
	{
		if(n==10)
			return 10;
		else
			return n*pro(n+1);
	}
}
