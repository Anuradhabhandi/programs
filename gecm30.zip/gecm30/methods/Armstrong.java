class Armstrong
{
	public static void main(String[] args) 
	{
	   int num=153,rem,sum=0,num1;
	   num1=num;
	   while(num>0){
		rem=num%10;
	    num=num/10;
		sum=sum*arm(rem);
	   }
	   if(sum==num1)
		{
		   System.out.println("Armstrong number");
		}
		else
		{
			System.out.println("not a Armstrong number");
		}
	}
	public static int arm(int num)
	{
		int res=1;
		for(int i=1;i<=num;i++)
			res=res*i;
        return res;
}
}
