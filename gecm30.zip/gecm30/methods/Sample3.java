class Sample3 
{
	public static void main(String[] args) 
	{
	   int num=145,rem,sum=0,num1;
	   num1=num;
	   while(num>0){
		rem=num%10;
	    num=num/10;
		sum=sum+fact(rem);
	   }
	   if(sum==num1)
		{
		   System.out.println("strong number");
		}
		else
		{
			System.out.println("not a strong number");
		}
	}
	public static int fact(int num)
	{
		int fact=1;
		for(int i=1;i<=num;i++)
			fact=fact*i;
        return fact;
}
}
