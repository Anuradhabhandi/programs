class Digit
{
	public static void main(String[] args) 
	{
		int num=1234;
		int sum=0;
		sumOf(num,sum);
		System.out.println("main ends...");

	}
	public static void sumOf(int num1,int sum1)
	{
		int rem;
		while(num1>0)
		{
			rem=num1%10;
			if(num1%2==1)
			System.out.println(rem);
			num1=num1/10;
			sum1=sum1+rem;
		}
	}
}
