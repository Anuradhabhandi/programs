class ATM 
{
	String branchName;
	String loc;
	String tOS;

	public void deposit(){
		System.out.println("deposit the money ");
	}
    public void withDraw(){
		System.out.println("withdrawing the moeny");
	}

public ATM(String branchName,String loc,String tOS)
	{
	this.branchName=branchName;
	this.loc=loc;
	this.tOS=tOS;
	}

}

