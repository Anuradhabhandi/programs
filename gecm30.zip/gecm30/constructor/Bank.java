class Bank 
{
	public static void main(String[] args) 
	{
		ATM a1=new ATM("SBI","GLB","MANUAL");
		a1.deposit();
		a1.withDraw();

		    
	}
}

