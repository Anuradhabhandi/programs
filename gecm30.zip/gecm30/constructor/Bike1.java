class Bike1 
{
	public static void main(String[] args) 
	{
		Bike b1=new Bike("honda",20000);
		b1.accelerate();
		b1.speed();
	}
}
