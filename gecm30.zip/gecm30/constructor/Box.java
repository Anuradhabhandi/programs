class Box 
{
  double l;
  double h;
  double w;
  public Box(double l,double,h,double w)
	{
	  this.l=l;
	  this.h=h;
	  this.w=w;
	}

}
