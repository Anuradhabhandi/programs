class AreaOfRectangle1
{
	public static void main(String[] args) 
	{
		Rectangle1 r1= new Rectangle1(4.5,3.5);
		r1.areaOfRectangle1();

		
	}
}
