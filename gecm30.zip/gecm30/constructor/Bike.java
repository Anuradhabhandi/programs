class Bike 
{
	String model;
	int price;
	public void accelerate()
	{
		System.out.println("accelerate");
	}
	public void speed()
	{
		System.out.println("break");
	}
	public Bike(String model,int price)
	{
		this.model=model;
		this.price=price;
}
}