class PubG 
{
	public static void main(String[] args) 
	{
		Gun g1=new Gun("pistol",6);
		g1.shoot();
	}
}
