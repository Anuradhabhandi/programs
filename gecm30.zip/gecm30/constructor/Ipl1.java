class Ipl1 
{
	public static void main(String[] args) 
	{
		Ipl i=new Ipl("batsman","mumbaiindian","banglore","blue",6,4,8,11)
			i.display();
	}
}
