class Circle1
{
	static double pi=3.14;
	double r;
	public void areaOfCircle1{
	 System.out.println(" area of circle:"+(Circle1.pi*this.r*this.r));
	}
	public Circle1(double r){
        this.r=r;
	}

}
