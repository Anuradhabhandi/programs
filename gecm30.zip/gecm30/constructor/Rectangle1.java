class Rectangle1
{
	double length;
	double breadth;

	public Rectangle1(double length,double breadth){
	this.length=length;
	this.breadth=breadth;
}
	
	public void areaOfRectangle1(){
		System.out.println("Area of rec is: "+(this.length*this.breadth));
	}
	

}
