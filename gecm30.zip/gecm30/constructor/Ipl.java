class Ipl 
{
	String coach;
	String tn;
	String loc;
	String color;
	int run;
	int wicket;
	int nob;
	int nom;
	public Ipl(String coach,String tn)
	{
		this.coach=coach;
		this.tn=tn;
	}
	public Ipl(String coach,String tn,String loc,String color)
	{
		this(coach,tn);
		this.loc=loc;
		this.color=color;
	}
	public Ipl(String coach,String tn,String loc,String color,int run,int wicket)
	{
		this(loc,color);
		this.run=run;
		this.wicket=wicket;
	}

	public Ipl(String coach,String tn,String loc,String color,int run,int wicket,int nob,int nom)
	{
		this(run,wicket);
		this.nob=nob;
		this.nom=nom;
	}
	public void display()
	{
		System.out.println(coach+" "+tn+" "+loc+" "+color+" "+run+" "+wicket+" "+nob+" "+nom);
}

}