class Student 
{
	String name;
	double tp,twp,dp;
	public Student(String name,double tp)
	{
		this.name=name;
		this.tp=tp;
	}
	public Student(String name,double tp,double twp)
	{
		this(name,tp);
		this.twp=twp;
	}
	public Student(String name,double tp,double twp,double dp)
	{
		this(name,tp,twp);
		this.dp=dp;
	}
	public void qualification()
	{
		System.out.println("name:"+this.name);
		System.out.println("tenth percentage:"+this.tp);
		if(this.twp!=0.0)
		{
			System.out.println("twelth percentage:"+this.twp);
		}
		if(this.dp!=0.0)
		{
            System.out.println("degree percentage:"+this.dp);
		}
	}
}
