class Student1 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		Student s1=new Student("a",35.36);
		s1.qualification();
		Student s2=new Student("b",40.36,50.7);
		s2.qualification();
		Student s3=new Student("c",60.50,50.60,40.7);
		s3.qualification();

	}
}
