class AreaOfCircle1
{
	public static void main(String[] args) 
	{
		Circle1 c1=new Circle1(7.5);
		c1.areaOfCircle1();
	}
}
