class User 
{
	public static void main(String[] args) 
	{
		A obj=new B(10,20);
		System.out.println(obj.toString());
		System.out.println(obj.i);
		//System.out.println(obj.j);

		Object obj1=new B(10,20);
		System.out.println(obj1.toString());
		//System.out.println(obj1.i);
		//System.out.println(obj1.j);

		B o=((B)obj);
		System.out.println(o.toString());
		System.out.println(o.i);
		System.out.println(o.j);

		B o1=((B)obj);
		System.out.println(((B)obj).toString());
		System.out.println(((B)obj).i);
		System.out.println(((B)obj).j);



	}
}
