class A 
{
	int i;
	public A(int i)
	{
		this.i=i;
	}
}


